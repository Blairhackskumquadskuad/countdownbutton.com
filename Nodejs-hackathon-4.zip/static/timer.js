const fs = require('fs');
var startTime = parseInt(fs.readFile("timeStop.txt"));
console.log(startTime);
function timer(startTime){
  var currTime = new Date().getTime();
  distance = startTime-currTime;
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60).toString());
  var seconds = Math.floor((distance % (1000 * 60)) / 1000).toString();
  if(seconds.length < 2){
    seconds += "0"
  }
  if(minutes.length < 2){
    minutes += "0"
  }
  document.getElementById('timerButton').value = "00" + ":" + minutes + ":" + seconds;
}